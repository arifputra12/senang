<?php
    class Login extends CI_Controller 
    {
        function index()
        {
            $this->load->view('page/login');
        }
        
        function sign()
        {
            $nama = $this->input->post('username');
            $sandi=$this->input->post('password');
            
            if($nama != "koperasi")
            {
                echo "<script>alert('salah');</script>";
                redirect('login', 'refresh');
            }
            else if($sandi != "bahagia")
            {
                echo "<script>alert('salah');</script>";
                redirect('login', 'refresh');
            }
            else
            {
                $data_session=array('nama'=>$nama,'status'=>'login');
                $this->session->set_userdata($data_session);
                redirect('utama', 'refresh');
            }
        
        }
        
        function signout()
        {
            
        $this->session->unset_userdata('nama');
        redirect('login');
            
        }
    }

?>