<?php
    class Utama extends CI_Controller 
    {
        
        function __construct()
        {
        parent::__construct();
         if($this->session->userdata('status') != TRUE ){
            redirect('login','refresh');
        };
            
        $this->load->database();
        }
        function index()
        {
            $this->load->view('page/header');
            $this->load->view('page/footer');
        }
    }

?>