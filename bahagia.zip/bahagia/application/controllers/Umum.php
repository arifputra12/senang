<?php
	class Umum extends CI_Controller
	{
		function __construct()
		{
			parent::__construct();
			if ($this->session->userdata('status') != TRUE) {
				redirect('login', 'refresh');
			}
			;
			$this->load->model('m_data');
			$this->load->database();
			$this->load->library('form_validation');
		}
		
		function bkm()
		{
			$tahun = date("Y");
			$sql   = $this->db->query("select max(cast(urutan AS SIGNED )) as urutan,tahun from nomor where jenis='a' or jenis='c' and tahun=" . $tahun)->result();
			// print_r ($sql);
			
			foreach ($sql as $row) {
				$row->urutan;
				$row->tahun;
			}
			
			$data = array(
				'urutan' => $row->urutan,
				'tahun' => $row->tahun
			);
			if (isset($data['urutan'])) {
				$urutan = $data['urutan'] + 1;
				$gabung = str_pad($urutan, 3, '0', STR_PAD_LEFT);
			} else {
				$urutan = 1;
			}
			
			$nomer = array(
				'urutan' => $urutan,
				'gabung' => $gabung
			);
			// print_r ($gabung);
			
			$this->load->view('page/header');
			$this->load->view('page/v_umumBKM', $nomer);
			$this->load->view('page/footer');
		}
		
		function bkk()
		{
			$tahun = date("Y");
			$sql   = $this->db->query("select max(cast(urutan AS SIGNED )) as urutan,tahun from nomor where jenis='b' or jenis='d' and tahun=" . $tahun)->result();
			// print_r ($sql);
			
			foreach ($sql as $row) {
				$row->urutan;
				$row->tahun;
			}
			
			$data = array(
				'urutan' => $row->urutan,
				'tahun' => $row->tahun
			);
			
			if (isset($data['urutan'])) {
				$urutan = $data['urutan'] + 1;
				$gabung = str_pad($urutan, 3, '0', STR_PAD_LEFT);
			} else {
				$urutan = 1;
			}
			
			$nomer = array(
				'urutan' => $urutan,
				'gabung' => $gabung
			);
			// print_r ($gabung);
			
			$this->load->view('page/header');
			$this->load->view('page/v_umumBKK', $nomer);
			$this->load->view('page/footer');
		}
		
		function insert_bkk()
		{
			date_default_timezone_set("Asia/Jakarta");
			$jenis  = "d";
			$query  = $this->db->query('select max(id) as nomor from nomor');
			$row    = $query->row_array();
			$lastid = $row['nomor'];
			// die($lastid);
			
			if ($lastid == 0) {
				$last = 1;
			} else {
				$last = $row['nomor'] + 1;
			}
			
			$urutan      = $this->input->post('urutan');
			$nama        = $this->input->post('nama');
			$wilayah     = $this->input->post('wilayah');
			$uraian      = $this->input->post('uraian');
			$jumlah      = $this->input->post('jumlah');
			$total       = $this->input->post('total');
			$tanggal     = date("Y/m/d");
			$tahun       = date("Y");
			$final_array = array();
			$length      = count($uraian);
			
			for ($i = 0; $i < $length; $i++) {
				
				$final_array[$i]['id_nomor'] = $last;
				$final_array[$i]['nama']     = $nama;
				$final_array[$i]['wilayah']  = $wilayah;
				$final_array[$i]['uraian']   = $uraian[$i];
				$final_array[$i]['jumlah']   = $jumlah[$i];
				$final_array[$i]['total']    = $total;
				$final_array[$i]['tahun']    = $tahun;
			}
			// var_dump($final_array);
			
			$this->db->insert_batch('umum', $final_array);
			
			if ($jenis == "d") {
				$data = array(
					'jenis' => $jenis,
					'urutan' => $urutan,
					'tahun' => $tahun,
					'tanggal' => $tanggal
				);
				$this->m_data->input_data($data, 'nomor');
				redirect('umum/bkk', 'refresh');
			}
		}
		
		function insert_bkm()
		{
			date_default_timezone_set("Asia/Jakarta");
			$query  = $this->db->query('select max(id) as nomor from nomor');
			$row    = $query->row_array();
			$lastid = $row['nomor'];
			// die($lastid);
			
			if ($lastid == 0) {
				$last = 1;
			} else {
				$last = $row['nomor'] + 1;
			}
			
			
			$jenis       = "c";
			$urutan      = $this->input->post('urutan');
			$nama        = $this->input->post('nama');
			$wilayah     = $this->input->post('wilayah');
			$uraian      = $this->input->post('uraian');
			$jumlah      = $this->input->post('jumlah');
			$total       = $this->input->post('total');
			$tanggal     = date("Y/m/d g:i:s");
			$tahun       = date("Y");
			$final_array = array();
			$length      = count($uraian);
			for ($i = 0; $i < $length; $i++) {
				
				$final_array[$i]['id_nomor'] = $last;
				$final_array[$i]['nama']     = $nama;
				$final_array[$i]['wilayah']  = $wilayah;
				$final_array[$i]['uraian']   = $uraian[$i];
				$final_array[$i]['jumlah']   = $jumlah[$i];
				$final_array[$i]['total']    = $total;
				$final_array[$i]['tahun']    = $tahun;
			}
			
			// var_dump($final_array);
			
			$this->db->insert_batch('umum', $final_array);
			if ($jenis == "c") {
				$data2 = array(
					'jenis' => $jenis,
					'urutan' => $urutan,
					'tahun' => $tahun,
					'tanggal' => $tanggal
				);
				$this->m_data->input_data($data2, 'nomor');
				redirect('umum/bkm', 'refresh');
			}
		}
		function get_bkk()
    	{
        
        $offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $limit  = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
        $offset = ($offset - 1) * $limit;
        
        $sql    = "SELECT nama,nomor.urutan,nomor.jenis,umum.id,wilayah,total,GROUP_CONCAT(uraian separator ',') as uraian,GROUP_CONCAT(jumlah separator ',') as jumlah from umum inner join nomor on umum.id_nomor=nomor.id 
				   where nomor.jenis='d' and nomor.urutan='010'";
		// $sql2    = "SELECT GROUP_CONCAT(uraian separator ',') as uraian,GROUP_CONCAT(jumlah separator ',') as jumlah 
		//             from umum inner join nomor on umum.id_nomor=nomor.id where nomor.jenis='d' and nomor.urutan='010'";
        $result['count'] = $this->db->query($sql)->num_rows();
        $sql .= " LIMIT {$offset},{$limit}";
		$result['data'] = $this->db->query($sql)->result_array();
		//$result['data2'] = $this->db->query($sql2)->result_array();
        $i              = 0;
		$rows           = array();
		//$baris           = array();
        

        foreach ($result['data'] as $r) {
			$uraian=explode(",",$r['uraian']);
			$jumlah=explode(",",$r['jumlah']);
			//  echo "<pre>";
			//  print_r($jumlah);
			//  echo "</pre>";
			$rows[$i]['nama']			=$r['nama'];
			$rows[$i]['urutan']			=$r['urutan'];
			$rows[$i]['wilayah']		=$r['wilayah'];
			$rows[$i]['total']			=$r['total'];
			$rows[$i]['id']				=$r['id'];
			$rows[$i]['jenis']			=$r['jenis'];
			for($j=0;$j<count($uraian);$j++){
				$namauraian = "uraian_".$j;
				$rows[$i][$namauraian] 	= $uraian[$j];
			}
			for($k=0;$k<count($jumlah);$k++){
				$namajumlah = "jumlah_".$k;
				$rows[$i][$namajumlah] 	= $jumlah[$k]; 
			}
			 $rows[$i]['curaian']		= count($uraian);
			$rows[$i]['cjumlah']		= count($jumlah);
			// $rows[$i]['uraian'] 	    = $uraian;
			// $rows[$i]['jumlah'] 	    = $jumlah;
			 $i++;
			
	   }
	//    foreach($result['data2'] as $b)
	//    {
	// 	  $baris[$i]['uraian'] 	= $b['uraian'];
	// 	  $baris[$i]['jumlah'] 	= $b['jumlah'];
	// 	  $i++;
	//    }

        
          $result = array(
             'total' => $result['count'],
			 'rows' => $rows
         );
		echo json_encode($result); 
		//$a=$this->load->view('page/header',$result);
		//print_r($a);
		
		
    }
	}
?>