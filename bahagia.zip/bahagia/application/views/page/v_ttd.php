<section class="section">
    <div class="row sameheight-container">
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/default/easyui.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/icon.css'); ?>">
	<script type="text/javascript" src="<?php echo base_url('asset/easyui153/jquery.easyui.min.js'); ?>"></script>
</head>
<body>
       <div class="subtitle-block">
               <h4>Menu Pengaturan Tanda Tangan</h4>
               <h6>KOPERASI BAHAGIA JOMBANG</h6>
            </div>
    <?php $url_data = base_url('ttd/get_ttd');?>
	<table id="dg" title="Peserta" class="easyui-datagrid" style="width:1050px;height:380px"
			url="<?php echo $url_data; ?>"
			toolbar="#toolbar" pagination="true"
			rownumbers="true" fitColumns="true" singleSelect="true">
		<thead>
			<tr>
				<th field="identitas" width="50">Identitas</th>
                <th field="untuk" width="50">Untuk</th>
                <th field="tahun" width="50">Tahun</th>
                <th field="status" width="50">Status</th>
			</tr>
		</thead>
	</table>
	<div id="toolbar">
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-add" plain="true" onclick="newttd()">Tambah</a>
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-edit" plain="true" onclick="editttd()">Edit</a>
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="destroyttd()">Hapus</a>
	</div>
	
	<div id="dlg" class="easyui-dialog" style="width:400px;height:280px;padding:10px 20px"
			closed="true" buttons="#dlg-buttons">
		<div class="ftitle">Data Identitas Tanda Tangan</div>
		<form id="fm" method="post" novalidate>
			<div class="fitem">
				<label>Identitas:</label>
				<input name="identitas" class="easyui-textbox" required="true">
			</div>
            <div class="fitem">
				<label>Untuk:</label>
				<input name="untuk" class="easyui-textbox" required="true">
            </div>
            <div class="fitem">
				<label>Tahun:</label>
				<span><?php echo date('Y'); ?></span>
            </div>
            <div class="fitem" id="kondisi">
                <label>Status:</label>
                <select id="status" class="easyui-combobox" name="status" style="width:160px;" >
                    <option select>Pilih</option>
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                </select>
            </div>
		</form>
	</div>
	<div id="dlg-buttons">
		<a href="javascript:void(0)" class="easyui-linkbutton c6" iconCls="icon-ok" onclick="savettd()" style="width:90px">Simpan</a>
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:$('#dlg').dialog('close')" style="width:90px">Batal</a>
	</div>
    
<script type="text/javascript">
    $('#dg').datagrid({
    loadMsg: "mohon tunggu sebentar",
	});
	
	$("#status").combobox({
	panelHeight:'auto'
	});
		var url;
		function newttd(){
			$('#dlg').dialog('open').dialog('setTitle','Data Tanda Tangan');
			$('#fm').form('clear');
            $('#kondisi').hide();
			url = '<?php echo site_url('ttd/insert_ttd');?>';
		}
		function editttd(){
			var row = $('#dg').datagrid('getSelected');
            $('#kondisi').show();
			if (row){
				$('#dlg').dialog('open').dialog('setTitle','Edit Data Tanda Tangan');
				$('#fm').form('load',row);
				url ='<?php echo site_url('ttd/update_ttd');?>/'+row.id+'/'+row.nomor_daftar;
                //alert(url);
			}
		}
		function savettd(){
			$('#fm').form('submit',{
				url: url,
				onSubmit: function(){
					return $(this).form('validate');
				},
				success: function(result){
					var result = eval('('+result+')');
					if (result.errorMsg){
						$.messager.alert({
							title: 'Error',
							msg: result.errorMsg
						});
					} else {
                        $.messager.alert({
							title: 'INFO',
							msg: result.successMsg
						});
						$('#dlg').dialog('close');		// close the dialog
						$('#dg').datagrid('reload');	// reload the user data
                    }
				}
			});
            
		}
        
		function destroyttd(){
			var row = $('#dg').datagrid('getSelected');
			if (row){
				$.messager.confirm('Confirm','Apakah data ini ingin dihapus?',function(r){
					if (r){
						$.post("<?php echo site_url('ttd/hapus_ttd'); ?>",{id:row.id},function(result){
							if (result.success){
								$('#dg').datagrid('reload');	// reload the user data
							} else {
								$.messager.show({	// show error message
									title: 'Error',
									msg: result.errorMsg
								});
							}
						},'json');
					}
				});
			}
		}
        
</script>
	<style type="text/css">
		#fm{
			margin:0;
			padding:10px 30px;
		}
		.ftitle{
			font-size:14px;
			font-weight:bold;
			padding:5px 0;
			margin-bottom:10px;
			border-bottom:1px solid #ccc;
		}
		.fitem{
			margin-bottom:5px;
		}
		.fitem label{
			display:inline-block;
			width:80px;
		}
		.fitem input{
			width:160px;
		}
	</style>
</body>
</html>
</div>
</section>