      <html>
         <head>
            <meta charset="UTF-8">
             <script type="text/javascript" src="<?php //echobase_url('asset/js/jquery.min.js'); ?>"></script>
             <script type="text/javascript" src="<?php echo base_url('asset/js/numeral.min.js'); ?>"></script>
         </head>
         <style>
	label.error {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
        padding:1px 20px 1px 5px;
        margin-left:70px;
    }
	</style>

         <body>
               <div class="subtitle-block">
               <h4>Menu Umum || BKM</h4>
               <h6>KOPERASI BAHAGIA JOMBANG</h6>
            </div>
            <section class="section">
               <div class="row sameheight-container">
                  <div class="col-md-12">
                     <div class="card card-block">
                        <div class="title-block">
                           <h3 class="title"> Tanggal : <?php echo date("d/m/Y"); ?> </h3>
                           <br>
                        </div>
                        <?php
                        $attrib=array('class'=>'form-inline',
                                      'id'=>'ubkm-form'
                                    );
                        echo form_open('umum/insert_bkm',$attrib); ?>
                        <table width="941">
                              <tr>
                                <td width="210"><span style="margin-right:14px;">Nama:</span>
                                  <input name="nama" type="text" class="form-control" id="nama">
                                  <br>
                                </td>
                                <td rowspan="2"><span style="margin-left:300px;">Nomer BKM:</span>
                                <input name="urutan" type="text" class="form-control" value="<?php print_r ($gabung); ?>" readonly></td>
                              </tr>
                              <tr>
                                <td><span style="margin-right:6px;">Wilayah:</span><input name="wilayah" type="text" id="wilayah" class="form-control"></td>
                              </tr>
                        </table>
                           <table  class="table table-striped table-bordered table-hover" id="tblAddRow" >
                            <thead>
                               <tr>
                                <td>Uraian</td>
                                <td>Jumlah</td>
                                <td>Tambah Baris</td>
                              </tr>
                               </thead>
                               <tfoot>
                                <tr>
                                <td colspan="3" align="center" >Total:<p></p>
                                <input type="hidden" name="total" id="total"></td>
                               </tr>
                               <tr>
                                <td colspan="4" align="center">
                                <button type="submit" name='submit' class="btn btn-success" id="cetak">Cetak</button>&nbsp;
                                </td>
                               </tr>
                               </tfoot>
                              <tbody>
                               <tr>
                                <td><textarea rows="2" cols="50" name="uraian[]" class="form-control boxed" required wrap="hard"></textarea></td>
                                <td><input type="text" name="jumlah[]" class='textboxt' onkeypress="return isNumberKey(event)" id="jumlah"></td>
                                <td><input type="button" name="tambah" class="btn btn-primary" value="Tambah" id="btnAddRow"></td>
                              </tr>
                            </tbody>
                           </table>
                        </form>
                     </div>
                  </div>
               </div>
            </section>
         </body>
      </html>
<script>
var newRowContent = "<tr><td><textarea rows='2' cols='50' name='uraian[]' required wrap='hard' class='form-control'></textarea></td>"+
    "<td><input type='text' name='jumlah[]' id='jumlah' class='textboxt' onkeypress='return isNumberKey(event)'></td><td>"+
    "<input type='button' name='hapus' class='btn btn-danger' value='Hapus' id='btnDeleteRow'></td></tr>";

$("#btnAddRow").click(function(){    
   $("#tblAddRow tbody").append(newRowContent);
});
   $('#tblAddRow').on('click', 'tr #btnDeleteRow', function(e) {
    var lenRow = $('#tblAddRow tbody tr').length;
    e.preventDefault();
    if (lenRow == 1 || lenRow <= 1) {
        alert("Can't remove all row!");
    } else {
        $(this).parents('tr').remove();
    }
});

$(document).on("keyup", ".textboxt", function() {
    var sum = 0;    
    $(".textboxt").each(function(){
        sum += +$(this).val(); 
    });
    $("p").html(sum);
    $("#total").val (sum);   
});
    
    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;
        if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
    }

    $("#cetak").click(function()
    {   
   
        window.open('<?php echo base_url('report/cetakumumbkm'); ?>');
    });
   // validate signup form on keyup and submit
		$("#ubkm-form").validate({
            
			rules: {
				nama: "required",
                wilayah: "required",
			},
			messages: {
				nama: "Kolom Nama Kosong",
                wilayah: "Kolom Wilayah Kosong",
			}
		});
        $.validator.messages.required = "Kolom Uraian Kosong";
</script>