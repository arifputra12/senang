<table border="1">
<?php $pinjaman=$bkk['0']['pinjaman']; ?>
  <tr>
    <td width="237"><p align="center">KOPERASI &quot;BAHAGIA&quot; KANKEMENAG</p></td>
    <td width="198" rowspan="2"><div align="center">BUKTI KAS KELUAR (BKK) </div></td>
    <td width="187">NO. BKK:<?php  print_r ($bkk['0']['urutan']);?></td>
  </tr>
  <tr>
    <td><div align="center">KABUPATEN JOMBANG </div></td>
    <td>TANGGAL: <?php echo date("d/m/Y"); ?></td>
  </tr>
  <tr>
  <td colspan="3">
	<table width="631">
        <tr>
       <td width="147">Telah terima dari: </td>
        <td><?php  print_r ($bkk['0']['nama']);?></td>
        <td colspan="2">Wilayah Gaji:&nbsp;&nbsp;<?php  print_r ($bkk['0']['wilayah']);?></td>
            </tr>
      <tr>
        <td>Banyaknya:</td>
        <td colspan="2"><div><?php echo "Rp ".number_format($pinjaman, 0, ",", ".");?></div></td>
        </tr>
      <tr>
        <td>Terbilang:</td>
        <td colspan="2"><div><?php  echo terbilang ($pinjaman);?></div></td>
        </tr>
      <tr>
        <td>Untuk Pembayaran:</td>
        <td colspan="2"><?php  $pinjaman=print_r ($bkk['0']['keperluan']);?></td>
        </tr>
        <tr>
        <td height="160">Diketahui Oleh,</td>
        <td width="194">Dibayarkan Oleh, </td>
        <td width="268">Diterima Oleh, </td>
      </tr>
      <tr>
        <td height="90"><?php  print_r ($ttd['0']['identitas']);?></td>
        <td><?php  print_r ($ttd2['0']['identitas']);?></td>
        <td></td>
      </tr>
      <table width="633" border="1">
  <tr>
    <td width="95">Bendahara</td>
    <td width="105">Bagian Akutansi</td>
    <td width="119">Kode Perk</td>
    <td width="120">DEBET</td>
    <td width="130">KREDIT</td>
  </tr>
  <tr>
    <td rowspan="6">&nbsp;</td>
    <td rowspan="6">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
    </td>
  </tr>
    </table>
    </td>
  </tr>
</table>
<br>
<button type="button" onclick="cetak();">Cetak Form BKK</button> || <button type="button" onclick="home();">Kembali ke menu</button>

<?php
	function penyebut($nilai) {
		$nilai = abs($nilai);
		$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
		$temp = "";
		if ($nilai < 12) {
			$temp = " ". $huruf[$nilai];
		} else if ($nilai <20) {
			$temp = penyebut($nilai - 10). " belas";
		} else if ($nilai < 100) {
			$temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
		} else if ($nilai < 200) {
			$temp = " seratus" . penyebut($nilai - 100);
		} else if ($nilai < 1000) {
			$temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
		} else if ($nilai < 2000) {
			$temp = " seribu" . penyebut($nilai - 1000);
		} else if ($nilai < 1000000) {
			$temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
		} else if ($nilai < 1000000000) {
			$temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
		} else if ($nilai < 1000000000000) {
			$temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
		} else if ($nilai < 1000000000000000) {
			$temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
		}     
		return $temp;
	}
 
	function terbilang($nilai) {
		if($nilai<0) {
			$hasil = "minus ". trim(penyebut($nilai));
		} else {
			$hasil = trim(penyebut($nilai));
		}     		
		return $hasil;
	}

?>
<script>
  function cetak()
  {
    window.open('<?php echo base_url('report/cetakformbkk'); ?>');
  }
  function home()
  {
    window.open('<?php echo base_url('simpan'); ?>');
  }
</script>