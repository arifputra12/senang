      <html>
         <head>
            <meta charset="UTF-8">
             <script type="text/javascript" src="<?php echo base_url('asset/js/jquery.min.js'); ?>"></script>
             <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/default/easyui.css'); ?>">
            <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/icon.css'); ?>">
            <script type="text/javascript" src="<?php echo base_url('asset/easyui153/jquery.easyui.min.js'); ?>"></script>
         </head>
         <body>
            <div class="subtitle-block">
               <h4>Menu Umum || BKK</h4>
               <h6>KOPERASI BAHAGIA JOMBANG</h6>
            </div>
            <section class="section">
               <div class="row sameheight-container">
                  <div class="col-md-12">
                     <div class="card card-block">
                        <div class="title-block">
                           <h3 class="title"> Tanggal : <?php echo date("d/m/Y"); ?> </h3>
                           <br>
                        </div>
                        <table class="table table-bordered">
                                    <tr>
                                        <td>
                                            <label>Hapus Nomor</label>
                                        </td>
                                        <td>
                                            <select name="edit" id="changemodal" class="form-control">
                                                <option velue="jenis" selected>--- Jenis ---</option>
                                                <option value="bkk">BKK</option>
                                                <option value="bkm">BKM</option>
                                            </select>
                                        </td>
                                        <tr>
                                            <td>
                                                <label>Input Nomor Manual</label>
                                            </td>
                                            <td>
                                                <button id="manual">Klik</button>
                                                <div id="textfield"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                </table>
                        <form class="form-inline" action="<?php echo site_url("umum/insert_bkk");?>" method="post">
                        <table width="941">
                              <tr>
                                <td width="210"><span style="margin-right:14px;">Nama:</span>
                                  <input name="nama" type="text" class="form-control" id="nama">
                                  <br>
                                </td>
                                <td rowspan="2"><span style="margin-left:300px;">Nomer BKK:</span>
                                    <input name="urutan" type="text" id="urutan" class="form-control" value="<?php print_r ($gabung); ?>" readonly>
                                  </td>
                              </tr>
                              <tr>
                                <td><span style="margin-right:6px;">Wilayah:</span><input name="wilayah" type="text" id="wilayah" class="form-control"></td>
                              </tr>
                            </table>
                           <table class="table table-striped table-bordered table-hover" id="tblAddRow">
                            <thead>
                               <tr>
                                <td>Uraian</td>
                                <td>Jumlah</td>
                                <td>Tambah Baris</td>
                              </tr>
                               </thead>
                               <tfoot>
                                <tr>
                                <td colspan="3" align="center" >Total:<p></p>
                                <input type="hidden" name="total" id="total"></td>
                               </tr>
                               <tr>
                                <td colspan="4" align="center"><input type="submit" name='submit' value="Cetak" class="btn btn-success" id="cetak">
                               </tr>
                               </tfoot>
                              <tbody>
                               <tr>
                                <td><textarea rows="2" cols="50" name="uraian[]"  class="form-control boxed"></textarea></td>
                                <td><input type="text" name="jumlah[]" id="jumlah" class="textboxt" onkeypress="return isNumberKey(event)"></td>
                                <td><input type="button" name="tambah" class="btn btn-primary" value="Tambah" id="btnAddRow"></td>
                              </tr>
                            </tbody>
                           </table>
                        </form>
                        <!-- The Modal Hapus Nomer BKK-->
                        <div id="myModal1" class="modal">
                                <!-- Modal content -->
                                <div class="modal-content">
                                        <div id="toolbar_bkk">
                                            <span>Nomor BKK:</span>
                                            <input nama="nobkk" id="nobkk" class="easyui-textbox" style="width:80px;">
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-search" plain="true" onclick="CariBkk()">Cari</a>
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" plain="true" onclick="editBkk()">Edit</a>
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="HapusBkk()">Hapus</a>
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" plain="true" onclick="CloseBkk()">Tutup</a>
                                        </div>
                                        <table id="dg" title="List Nomor BKK" class="easyui-datagrid" style="width:900px;height:350px" toolbar="#toolbar_bkk" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true">
                                        </table>
                                        <div id="dlg" class="easyui-dialog" style="width:400px;height:280px;padding:10px 20px"
                                            closed="true" buttons="#dlg-buttons">
                                        <div class="ftitle">Peserta Baru</div>
                                        <form id="fm" method="post" novalidate>
                                            <div class="fitem">
                                                <label>Nama:</label>
                                                <input name="nama" class="easyui-textbox" required="true">
                                            </div>
                                            <div class="fitem">
                                                <label>Wilayah Gaji:</label>
                                                <input name="wilayah" class="easyui-textbox" required="true">
                                            </div>
                                            <div class="fitem">
                                                <label>Urutan:</label>
                                                <input name="urutan" class="easyui-textbox" required="true" readonly>
                                            </div>
                                            <div class="fitem">
                                                <label>Uraian:</label>
                                                <input name="uraian" class="easyui-textbox" required="true">
                                                <input name="curaian" id="hitung">
                                                <!-- <input name="uraian_1" class="easyui-textbox" required="true"><br>
                                                <input name="uraian_2" class="easyui-textbox" required="true"> -->
                                            </div>
                                            <div class="fitem">
                                                <label>jumlah:</label>
                                                <input name="jumlah" class="easyui-textbox" required="true">
                                            </div>
                                            <div class="fitem">
                                                <label>Total:</label>
                                                <input name="total" class="easyui-textbox" required="true">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- The Modal Hapus Nomer BKM-->
                            <div id="myModal2" class="modal">
                                <!-- Modal content -->
                                <div class="modal-content">
                                    <?php $url_data = base_url('simpan/get_bkm');?>
                                        <div id="toolbar_bkm">
                                            <span>Nomor BKM:</span>
                                            <input nama="nobkm" id="nobkm" class="easyui-textbox" style="width:80px;">
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-search" plain="true" onclick="CariBkm()">Cari</a>
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="HapusBkm()">Hapus</a>
                                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" plain="true" onclick="CloseBkm()">Tutup</a>
                                        </div>
                                        <table id="dgg" title="List Edit BKM" class="easyui-datagrid" style="width:900px;height:350px" url="<?php echo $url_data; ?>" toolbar="#toolbar_bkm" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true">
                                            <thead>
                                                <tr>
                                                    <!-- <th field="jenis" width="50">jenis</th> -->
                                                    <th field="urutan" width="10">urutan</th>
                                                    <th field="tanggal" width="10">tanggal</th>
                                                    <!-- <th field="tahun" width="50">tahun</th> -->
                                                    <th field="keperluan" width="10">keperluan</th>
                                                    <th field="administrasi" width="10">administrasi</th>
                                                    <th field="asuransi" width="10">asuransi</th>
                                                </tr>
                                            </thead>
                                        </table>
                                </div>
                            </div>
                     </div>
                  </div>
               </div>
            </section>
         </body>
      </html>
<script type="text/javascript">
var newRowContent = "<tr><td><textarea rows='2' cols='50' name='uraian[]' id='uraian' class='form-control'></textarea></td>"+
    "<td><input type='text' name='jumlah[]' id='jumlah' class='textboxt' onkeypress='return isNumberKey(event)'></td><td>"+
    "<input type='button' name='hapus' class='btn btn-danger' value='Hapus' id='btnDeleteRow'></td></tr>";
    <?php $url_data = base_url('umum/get_bkk');?>
    $('#dg').datagrid({
    url:"<?php echo $url_data; ?>",
    columns:[[
        {field:'nama',title:'nama'},
        {field:'wilayah',title:'wilayah'},
        {field:'uraian_0',title:'uraian',align:'right'}
    ]]
    });
    var a=$("#hitung").val();
    var v=$("#hitung").val(a);
    var arr = $.makeArray(v);
    console.log(arr);
    $("#changemodal").change(function() {
    if ($(this).val() == 'bkk') {
        $("#myModal1").css("display", "block");
        $('#dg').datagrid('reload');
        $('#nobkk').textbox('enable');        
        //  alert("bkk");
    } else if ($(this).val() == 'bkm') {
        $("#myModal2").css("display", "block");
        $('#dgg').datagrid('reload');
        $('#nobkm').textbox('enable');
        //alert("bkm");
    }
});
$("#manual").click(function() {
    
        $.get("<?php echo site_url('simpan/manual_urutanbkk'); ?>", function(data){
            $("#textfield").append("<br><input type='text' name='bkk' id='bkk' class='form-control' placeholder='Input Nomor BKK'>");
            //$("#bkk").val(data);
            //$("#bkm").remove();
            //alert("sukses");
        
         //alert("bkk");
        });
        $.get("<?php echo site_url('simpan/manual_urutanbkm'); ?>", function(data){
            $("#textfield").append("<input type='text' name='bkm' id='bkm' class='form-control' placeholder='Input Nomor BKM'>");
            //$("#bkm").val(data);
            //$("#bkk").remove();
            //alert("sukses");
        });
        //alert("bkm");
    
});

// for($i=0;$curaian == 3;$i++;)
// {
//     $("#uraian").clone("*").appendTo("#fm").after("#uraian");
// }

function CloseBkk() {
    $("#myModal1").css("display", "none");
    $('#changemodal').val("jenis").change();
   
}

function CloseBkm() {
    $("#myModal2").css("display", "none");
    //$('#changemodal option[value=jenis]').attr('selected',true);
    $('#changemodal').val("jenis").change();
}
function editBkk(){
			var row = $('#dg').datagrid('getSelected');
            //alert(row);
			if (row){
				$('#dlg').dialog('open').dialog('setTitle','Edit User');
				$('#fm').form('load',row);
               // $('#fm').form('load','<?php echo base_url('umum/get_bkk')?>');
				//url ='<?php echo site_url('daftar/update_peserta');?>/'+row.id+'/'+row.nomor_daftar;
                //alert("aaaa");
			}
		}
$("#btnAddRow").click(function(){    
   $("#tblAddRow tbody").append(newRowContent);
});
   $('#tblAddRow').on('click', 'tr #btnDeleteRow', function(e) {
    var lenRow = $('#tblAddRow tbody tr').length;
    e.preventDefault();
    if (lenRow == 1 || lenRow <= 1) {
        alert("Can't remove all row!");
    } else {
        $(this).parents('tr').remove();
    }
});

$(document).on("keyup", ".textboxt", function() {
    var sum = 0;
    $(".textboxt").each(function(){
        sum += +$(this).val(); 
    });
    $("p").html(sum);
    $("#total").val (sum);
});
    
    function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
}
$("#cetak").click(function()
    {   
        window.open('<?php echo base_url('report/cetakumumbkk'); ?>');
    });

</script>