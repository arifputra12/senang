<html>
   <head>
      <meta charset="UTF-8">       
   </head>
   <body>
      <div class="subtitle-block">
         <h3 class="subtitle">KOPERASI BAHAGIA JOMBANG</h3>
      </div>
      <section class="section">
        <div class="row">
            <div class="col-xs-4">
                <div class="card">
                    <div class="card-block">
                    <div class="card-title-block">
                                            <h3 class="title"> Cetak Kas Harian </h3>
                                        </div>
                        <section class="example">
                            <div class="table-responsive">
                            <form action="<?php echo site_url('report/kasharian'); ?>" method="post" target="_blank">
                     <input class="form-control boxed" name="tanggal"  placeholder="Tanggal Cetak" id="datepicker" required="true" readonly/>
                     <br><input type="submit" name="submit" value="cetak" class="btn btn-success">
                  </form>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>
   </body>
</html>
<script>
$(function() {
    $("#datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy'
    });
});
</script>