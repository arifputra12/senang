<table border="1">
  <tr>
    <td><center>KOPERASI &quot;BAHAGIA&quot; KANKEMENAG</center></td>
    <td rowspan="2"><center>UMUM BUKTI KAS MASUK <br>(BKM)</center></td>
    <td>NO.BKM:<?php print_r ($grup['0']['urutan']); ?></td>
  </tr>
  <tr>
    <td><div align="center">KABUPATEN JOMBANG </div></td>
    <td>TANGGAL:<?php echo date("d/m/Y"); ?></td>
  </tr>
  <tr>
  <td colspan="3">
	<table>
      <tr>
        <td>Telah terima dari:</td>
        <td><?php  print_r ($grup['0']['nama']); ?></td>
        <td colspan="2">&nbsp;Wilayah Gaji:&nbsp;&nbsp;<?php print_r ($grup['0']['wilayah']); ?></td>
      <tr>
        <td>Banyaknya:</td>
        <td colspan="2"><div><?php print_r ($grup['0']['total']); ?><div></td>
        </tr>
      <tr>
        <td>Terbilang:</td>
        <td colspan="2"><div><?php print_r(terbilang ($grup['0']['total']));?></div></td>
        </tr>
      <tr>
			<td valign="top">Untuk Pembayaran:</td>
        <td colspan="2">
				<?php 
				foreach ($uraian as $row) {
				echo $row->uraian;
				echo "<br>";
				}
				?>
				</td>
      </tr>
      <tr>
        <td width="113">Diketahui Oleh, </td>
        <td width="194">Diterima Oleh, </td>
        <td width="268">Disetor Oleh, <br><br><br>
				<?php  print_r ($grup['0']['nama']); ?>
				</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
     
<?php
	function penyebut($nilai) {
		$nilai = abs($nilai);
		$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
		$temp = "";
		if ($nilai < 12) {
			$temp = " ". $huruf[$nilai];
		} else if ($nilai <20) {
			$temp = penyebut($nilai - 10). " belas";
		} else if ($nilai < 100) {
			$temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
		} else if ($nilai < 200) {
			$temp = " seratus" . penyebut($nilai - 100);
		} else if ($nilai < 1000) {
			$temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
		} else if ($nilai < 2000) {
			$temp = " seribu" . penyebut($nilai - 1000);
		} else if ($nilai < 1000000) {
			$temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
		} else if ($nilai < 1000000000) {
			$temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
		} else if ($nilai < 1000000000000) {
			$temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
		} else if ($nilai < 1000000000000000) {
			$temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
		}     
		return $temp;
	}
 
	function terbilang($nilai) {
		if($nilai<0) {
			$hasil = "minus ". trim(penyebut($nilai));
		} else {
			$hasil = trim(penyebut($nilai));
		}     		
		return $hasil;
	}

?>