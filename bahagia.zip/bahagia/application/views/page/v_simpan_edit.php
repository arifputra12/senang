<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/default/easyui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/easyui153/themes/icon.css'); ?>">
    <script type="text/javascript" src="<?php echo base_url('asset/easyui153/jquery.easyui.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('asset/js/numeral.min.js'); ?>"></script>
</head>

<body>
    <div class="subtitle-block">
        <h3>Menu Simpan Pinjam BKM dan BKK</h3>
        <h6>KOPERASI BAHAGIA JOMBANG</h6>
    </div>
    <section class="section">
        <div class="row sameheight-container">
            <div class="col-md-12">
                <div class="card card-block sameheight-item">
                    <fieldset class="form-inline">
                        <h3 class="title"> Tanggal :
                            <?php echo date("d/m/Y"); ?>
                        </h3>
                        <br>
                        <label>Edit</label>
                        <select style="margin-left:40px;" name="edit" id="changemodal" class="form-control">
                            <option checked value=" ">--- Jenis ---</option>
                            <option  value="bkk">BKK</option>
                            <option value="bkm">BKM</option>
                        </select>
                    </fieldset>
                    <br>
                    <form class="form-inline" name="simpan" id="fm">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td>
                                        <label class="control-label">Keperluan</label>
                                    </td>
                                    <td>
                                        <select name="jenis" class="form-control" id="keperluan">
                                            <option value=" " selected>--- Jenis ---</option>
                                            <option value="reguler1">Reguler 1</option>
                                            <option value="reguler2">Reguler 2</option>
                                            <option value="reguler3">Reguler 3</option>
                                            <option value="reguler4">Reguler 4</option>
                                            <option value="usp">USP</option>
                                            <option value="haji">Haji</option>
                                            <option value="ekstra">Ekstra</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="control-label">Nomer Pendaftaran</label>
                                    </td>
                                    <td>
                                        <input type="text" name="nopendaftaran" class="form-control" id="nopendaftaran" maxlength="4" onkeypress="return isNumberKey(event)" placeholder="Di Isi Angka">
                                        <br><span style="background-color: yellow;font-weight: bold;">Setelah Mengisi Tekan Enter</span>
                                    </td>
                                    <td>
                                        <label>Nama Pendaftar:</label>
                                    </td>
                                    <td><b><span id="hasilpendaftar">_________________</span></b></td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="control-label">Jumlah Pinjaman</label>
                                    </td>
                                    <td>Rp.
                                        <input type="text" name="pinjaman" value="<?php echo $bkk[0]['pinjaman']; ?>" class="form-control" id="pinjaman" onkeyup="hitung();" onkeypress="return isNumberKey(event)">
                                    </td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <label class="control-label">Lama Pinjaman</label>
                                    </td>
                                    <td>Bln
                                        <input type="text" name="lama" id="lama" class="form-control" onkeyup="hitung();" onkeypress="return isNumberKey(event)" maxlength="2">
                                    </td>
                                    <td>
                                        <label class="control-label">Asuransi</label>
                                    </td>
                                    <td>Rp.
                                        <input type=text name="asuransi" id="ass" class="form-control" readonly>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="control-label">Jumlah Angsuran</label>
                                    </td>
                                    <td>Rp.
                                        <input type=text name="nilai" class="form-control" readonly id="angsuran">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <fieldset class="form-group">
                            <input type="submit" value="Cetak" class="btn btn-primary" id="submit">
                        </fieldset>
                    </form>
                </div>
                <!-- The Modal BKK-->
                <div id="myModal1" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <?php $url_data = base_url('simpan/get_bkk');?>
                        <div>
                        <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-edit" plain="true" onclick="EditBkk()">Edit BKK</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-print" plain="true" onclick="PrintBkk()">Cetak</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" plain="true" onclick="CloseBkk()">Tutup</a>
                        </div>
                        <table id="dg" title="List Edit BKK" class="easyui-datagrid" style="width:900px;height:310px" url="<?php echo $url_data; ?>" toolbar="#toolbar" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true">
                            <thead>
                                <tr>
                                    <!-- <th field="jenis" width="50">jenis</th> -->
                                    <th field="urutan" width="10">urutan</th>
                                    <th field="tanggal" width="10">tanggal</th>
                                    <!-- <th field="tahun" width="50">tahun</th> -->
                                    <th field="keperluan" width="10">keperluan</th>
                                    <th field="pinjaman" width="10">pinjaman</th>
                                </tr>
                            </thead>
                        </table>                    
                        <div id="dlgbkk" class="easyui-dialog" style="width:400px;height:280px;padding:10px 20px" closed="true" buttons="#dlg-buttons">
                            <div class="ftitle">Form Edit BKK</div>
                            <form id="fmBkk" method="post" novalidate>
                                <div class="fitem">
                                    <label>Urutan:</label>
                                    <input name="urutan" class="easyui-textbox" required="true">
                                </div>
                                <div class="fitem">
                                    <label>Keperluan:</label>
                                    <input name="keperluan" class="easyui-textbox" required="true">
                                </div>
                                <div class="fitem">
                                    <label>Pinjaman:</label>
                                    <input name="pinjaman" class="easyui-textbox" required="true">
                                </div>
                            </form>
                        </div>
                        <div id="dlg-buttons">
                            <a href="javascript:void(0)" class="easyui-linkbutton c6" iconCls="icon-ok" onclick="savePeserta()" style="width:90px">Simpan</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:$('#dlg').dialog('close')" style="width:90px">Batal</a>
                        </div>
                    </div>
                </div>
                <!-- The Modal BKM-->
                <div id="myModal2" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <?php $url_data = base_url('simpan/get_bkm');?>
                        <div>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-edit" plain="true" onclick="EditBkm()">Edit BKM</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-print" plain="true" onclick="PrintBkm()">Cetak</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" plain="true" onclick="CloseBkm()">Tutup</a>
                        </div>
                        <table id="dgg" title="List Edit BKM" class="easyui-datagrid" style="width:900px;height:320px" url="<?php echo $url_data; ?>" toolbar="#toolbar" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true">
                            <thead>
                                <tr>
                                    <!-- <th field="jenis" width="50">jenis</th> -->
                                    <th field="urutan" width="10">urutan</th>
                                    <th field="tanggal" width="10">tanggal</th>
                                    <!-- <th field="tahun" width="50">tahun</th> -->
                                     <th field="keperluan" width="10">keperluan</th>
                                    <th field="administrasi" width="10">administrasi</th>
                                    <th field="asuransi" width="10">asuransi</th>
                                </tr>
                            </thead>
                        </table>
                        <div id="dlgbkm" class="easyui-dialog" style="width:400px;height:280px;padding:10px 20px" closed="true" buttons="#dlg-buttons">
                            <div class="ftitle">Form Edit BKM</div>
                            <form id="fmBkm" method="post" novalidate>
                                <div class="fitem">
                                    <label>Urutan:</label>
                                    <input name="urutan" class="easyui-textbox" required="true">
                                </div>
                                <div class="fitem">
                                    <label>Keperluan:</label>
                                    <input name="keperluan" class="easyui-textbox" required="true">
                                </div>
                                <div class="fitem">
                                    <label>Administrasi:</label>
                                    <input name="administrasi" class="easyui-textbox" required="true">
                                </div>
                                <div class="fitem">
                                    <label>Asuransi:</label>
                                    <input name="asuransi" class="easyui-textbox" required="true">
                                </div>
                            </form>
                        </div>
                        <div id="dlg-buttons">
                            <a href="javascript:void(0)" class="easyui-linkbutton c6" iconCls="icon-ok" onclick="savePeserta()" style="width:90px">Simpan</a>
                            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:$('#dlg').dialog('close')" style="width:90px">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
</body>
</html>
<script>
$("#changemodal").change(function(){
	if($(this).val() == 'bkk'){
       $("#myModal1").css("display","block"); 
       $('#dg').datagrid('reload');
     //  alert("bkk");
  } 
  else if($(this).val() == 'bkm'){
    $("#myModal2").css("display","block");
    $('#dgg').datagrid('reload');  
    //alert("bkk");
  }
});
function EditBkk(){
    var row = $('#dg').datagrid('getSelected');
			if (row){
				$('#dlgbkk').dialog('open').dialog('setTitle','Edit User');
				$('#fmBkk').form('load',row);
				url ='<?php echo site_url('simpan/update_bkk');?>/'+row.id;
                //alert(url);
			}
		}
function CloseBkk()
{
    $("#myModal1").click(function() {
    $("#myModal1").css("display","none"); 
    });
}
function EditBkm(){
    var row = $('#dgg').datagrid('getSelected');
			if (row){
				$('#dlgbkm').dialog('open').dialog('setTitle','Edit User');
				$('#fmBkm').form('load',row);
				url ='<?php echo site_url('daftar/update_peserta');?>/'+row.id;
                //alert(url);
			}
		}
function CloseBkm()
{
    $("#myModal2").click(function() {
    $("#myModal2").css("display","none"); 
    });
}

// $("#myModal2").click(function() {
//     $("#myModal2").css("display","none");
//     $("#dgg").css("display","block"); 
// });
function hitung() {
    var pinjam = $("#pinjaman").val().replace(/[^\d.-]/g, '');
    var lama = $("#lama").val();
    bagi = Math.round(pinjam / lama);
    var value = numeral(bagi).format('0,0');
    $(this).val(value);
    $('#angsuran').val(value);

    if (lama <= 36) {
        adm = pinjam * 0.01;
        var value = numeral(adm).format('0,0');
        $(this).val(value);
        $('#adm').val(value);

    } else {
        ass = pinjam * 0.015;
        var value = numeral(ass).format('0,0');
        $(this).val(value);
        $('#ass').val(value);

    }

    if (lama > 36) {
        adm = pinjam * 0.015;
        var value = numeral(adm).format('0,0');
        $(this).val(value);
        $('#adm').val(value);

    } else {
        ass = pinjam * 0.015;
        var value = numeral(ass).format('0,0');
        $(this).val(value);
        $('#ass').val(value);

    }

}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

$("#pinjaman").keyup(function() {
    var z = $("#pinjaman").val();
    var value = numeral(z).format('0,0');
    $(this).val(value);
    $('#pinjaman').val(value);
});


$("#nopendaftaran").keypress(function(event) {

    if (event.which == 13) {
        event.preventDefault();
        $('select').removeAttr('disabled');
        //$('#submit').attr('disabled', 'true');
        //var data = new FormData();
        var peserta = $('#nopendaftaran').val();
        if (peserta.length == 4) {
            $.ajax({
                url: "<?php echo site_url('simpan/cekdaftar'); ?>",
                type: 'POST',
                data: {
                    peserta: peserta
                },
                dataType: "html",
                success: function(data) {
                    //$('#hasilpendaftar').val(data);
                    $('#hasilpendaftar').html(data)
                    //console.log (peserta);

                }
            });
        }
    }
});

$("#keperluan").change(function() {
    $('#submit').removeAttr('disabled');
    $('input').removeAttr('disabled');
    //alert("aaa");
});

$("#fm").submit(function(e) {
    e.preventDefault();

    var keperluan = $('#keperluan').val();
    var pinjaman = $('#pinjaman').val().replace(/[^\d.-]/g, '');
    var asuransi = $('#adm').val().replace(/[^\d.-]/g, '');
    var administrasi = $('#ass').val().replace(/[^\d.-]/g, '');
    var nopendaftaran = $('#nopendaftaran').val();

    //alert(administrasi);
    // var jenis = $('#jenis').val();
    //if (jenis == "a") {
    $.ajax({
        url: "<?php echo site_url('simpan/insert_bkm'); ?>",
        type: 'POST',
        data: {
            keperluan: keperluan,
            asuransi: asuransi,
            administrasi: administrasi,
            nopendaftaran: nopendaftaran,
            //jenis:jenis,
            pinjaman: pinjaman
        },
        dataType: "html",
        success: function(data) {
            window.open('<?php echo base_url('report/bkm'); ?>');
            window.open('<?php echo base_url('report/bkk'); ?>');
            window.close('<?php echo base_url('simpan'); ?>');
            //console.log(data);
        }

    });
    //    } else {
    //        $.ajax({
    //            url: "<?php //echo site_url('simpan/insert_bkk'); ?>",
    //            type: 'POST',
    //            data: {
    //                keperluan: keperluan,
    //                pinjaman: pinjaman,
    //                nopendaftaran: nopendaftaran,
    //                jenis:jenis
    //            },
    //            dataType: "html",
    //            success: function(data) {
    //                window.open('<?php //echo base_url('report/bkk'); ?>');
    //                window.location.href = "<?php //echo base_url('simpan'); ?>";
    //            }
    //
    //        });
    //    }
});

$("#pinjaman, #lama").on('keyup keypress', function(e) {
    var keycode = e.keycode || e.which;
    if (keycode === 13) {
        alert("Tidak Boleh Tekan Enter");
        e.preventDefault();
        return false;
    }
});

$('input').attr('disabled', 'true');
$('select').attr('disabled', 'true');
$('#nopendaftaran').removeAttr('disabled');
$('#changemodal').removeAttr('disabled');

</script>
<style type="text/css">
		#fm{
            margin:0;
		}
		.ftitle{
			font-size:14px;
			font-weight:bold;
			padding:5px 0;
			margin-bottom:10px;
			border-bottom:1px solid #ccc;
		}
		.fitem{
			margin-bottom:5px;
		}
		.fitem label{
			display:inline-block;
			width:80px;
		}
		.fitem input{
			width:160px;
		}
</style>