<!doctype html>
<html class="no-js" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title> Sistem Koperasi BAHAGIA </title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
      
      <link rel="stylesheet" id="theme-style1" href="<?php echo base_url ('asset/css/app-green.css')?>">
      <link rel="stylesheet" id="theme-style1" href="<?php echo base_url ('asset/css/jquery-ui.css')?>">
      <link rel="stylesheet" id="theme-style1" href="<?php echo base_url ('asset/css/custom.css')?>">
      <link rel="stylesheet" id="theme-style1" href="<?php echo base_url ('asset/css/vendor.css')?>">
      
      <script type="text/javascript" src="<?php echo base_url('asset/js/jquery.min.js'); ?>"></script>
      <script type="text/javascript" src="<?php echo base_url('asset/js/jquery-ui.js'); ?>"></script>
      <script src="<?php echo base_url('asset/js/jquery-validation-1.17.0/dist/jquery.validate.js');?>"></script>
      
      
    </head>

   <body>
      <div class="main-wrapper">
      <div class="app" id="app">
      <header class="header">
         <div class="header-block header-block-collapse hidden-lg-up"> <button class="collapse-btn" id="sidebar-collapse-btn">
            <i class="fa fa-bars"></i>
            </button> 
         </div>
         <div class="header-block header-block-search hidden-sm-down">
         </div>
         <div class="header-block header-block-buttons"> 
         </div>
         <div class="header-block header-block-nav">
            <ul class="nav-profile">
              <a href="<?php echo site_url ('login/signout')?>"><button type="button" class="btn btn-danger">Logout</button></a>
            </ul>
         </div>
      </header>
      <aside class="sidebar">
         <div class="sidebar-container">
            <div class="sidebar-header">
               <div class="brand">
                  <div class="logo"> <span class="l l1"></span> <span class="l l2"></span> <span class="l l3"></span> <span class="l l4"></span> <span class="l l5"></span></div>
               </div>
            </div>
            <nav class="menu">
               <ul class="nav metismenu" id="sidebar-menu">
                  <li> <a href="<?php echo site_url('utama'); ?>">
                     <i class="fa fa-home"></i> Dashboard
                     </a> 
                  </li>
                  <li> <a href="<?php echo site_url('simpan'); ?>">
                     <i class="fa fa-money"></i> Simpan Pinjam
                     </a>
                  </li>
                  <li> <a href="<?php echo site_url('umum/bkm'); ?>">
                     <i class="fa fa-shopping-cart"></i>UMUM Bukti Kas Masuk (BKM)
                     </a> 
                  </li>
                  <li> <a href="<?php echo site_url('umum/bkk'); ?>">
                     <i class="fa fa-shopping-cart"></i>UMUM Bukti Kas Keluar (BKK)
                     </a> 
                  </li>
                   <li> <a href="<?php echo site_url('kas'); ?>">
                     <i class="fa fa-print"></i>Cetak Kas Harian
                     </a> 
                  </li>
                  <li> <a href="<?php echo site_url('daftar'); ?>">
                     <i class="fa fa-book"></i> Daftar
                     </a>
                  </li>
                  <li> <a href="<?php echo site_url('ttd'); ?>">
                     <i class="fa fa-cogs" ></i>Pengaturan Tanda Tangan
                     </a> 
                  </li>
               </ul>
            </nav>
         </div>
      </aside>
      <div class="sidebar-overlay" id="sidebar-overlay"></div>
      <article class="content dashboard-page">
      