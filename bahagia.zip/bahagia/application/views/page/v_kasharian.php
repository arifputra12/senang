<table border="1">
   <tr>
        <td rowspan="2">Tanggal</td>
      <td colspan="2">
         <center>
            No Bukti
         </center>
      </td>
      <td rowspan="2">
         <center>Uraian</center>
      </td>
      <td rowspan="2">
         <center>Masuk</center>
      </td>
      <td rowspan="2">
         <center>Keluar</center>
      </td>
   </tr>
   <tr>
      <td>BKM</td>
      <td>BKK</td>
   </tr>
   <?php
    //CATATAN
    // "a"= bkm "b"= bkk "c"=Ubkm "d"=Ubkk
    $sum=$penjumlahan=0;
    foreach ($data as $row)
    {
    //a
    $administrasi=$row->administrasi;
    $asuransi=$row->asuransi;
    //b
    $pinjaman=$row->pinjaman;
    //c dan d
    $jumlah=$row->jumlah;
    //jenis transaksi
    $jenis=$row->jenis;
        
    if($jenis == "a")
    {
        $sum+=$administrasi+$asuransi;
    }
    if($jenis == "b" || $jenis == "c")
    {
        $sum+=$administrasi+$asuransi+$jumlah;
    }
    if($jenis == "c")
    {
        $penjumlahan+=$pinjaman;
    }
    if($jenis == "b" || $jenis == "d")
    {
        $penjumlahan+=$pinjaman+$jumlah;
    }
    ?>
   <tr>
       <td>
           <?php 
        $tanggal=explode ('-',$row->tanggal);
        echo $tanggal[2].'-'.$tanggal[1].'-'.$tanggal[0];
        
           ?>
       </td>
      <td>
         <?php
            $jenis= $row->jenis;
            if($jenis == "a")
            {
               echo $row ->urutan;
            }
            if($jenis == "c")
            {
               echo $row ->urutan;
            }  
            ?>
      </td>
      <td>
         <?php 
            $jenis= $row->jenis;
            if($jenis == "b")
            {
                echo $row ->urutan;
            }
            if($jenis == "d")
            {
                echo $row ->urutan;
            }
                        
            
            ?>
      </td>
      <td>
         <?php 
            $jenis=$row->jenis;
            $keperluan=$row->keperluan;
            $nama=$row->jeneng;
            if($jenis == "a")
            {
                echo "Administrasi ".$nama;
            }
            elseif($jenis == "b")
            {
                echo "Pinjaman ".$keperluan." ".$nama;
            }
            elseif($jenis== "c")
            {
                echo $row->uraian;    
            }
            else
            {
                echo $row->uraian;
            }
            //echo 'Administrasi '.$row->nama_peserta;
            //echo ' || '.$row->wilayah_gaji; 
            ?>
      </td>
      <td>
         <?php
            $jenis=$row->jenis;
            $jumlah=$row->jumlah;
            
            if($jenis == "a")
            {
            //echo"aaa";
            echo $row->administrasi;
            //echo ' || '.$row->asuransi;
            }
            if($jenis == 'c')
            {
                echo $jumlah;
            }
            
            ?>
      </td>
      <td>
         <?php 
            $jenis=$row->jenis;
            $jumlah=$row->jumlah;
            $pinjaman=$row->pinjaman;
            if($jenis == "b")
            {
            echo $pinjaman;
            }
            elseif($jenis == "d")
            {   
            echo $jumlah;
            }      
            ?>
      </td>
   </tr>
   <?php 
            $jenis=$row->jenis;
            $jumlah=$row->jumlah;
            $ass=$row->asuransi;
            $nama=$row->jeneng;
            if($jenis == "a")
            {
            echo"<tr><td></td><td></td><td></td><td>Asuransi $nama</td><td>$ass</td><td></td></tr>";
            }
      } ?>
      <tr>
     <td colspan="4" align="right">Total</td>
     <td><?php echo $sum; ?></td>
     <td><?php echo $penjumlahan; ?></td>
   </tr>
</table>