<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title> KOPERASI BAHAGIA JOMBANG</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        <link rel="stylesheet" href="<?php echo base_url('template/css/vendor.css');?>">
        <link rel="stylesheet" id="theme-style" href="<?php echo base_url('template/css/app.css');?>">
        <link rel="stylesheet" id="theme-style1" href="<?php echo base_url ('template/css/app-green.css')?>">
    </head>
    <body>
        <div class="auth">
            <div class="auth-container">
                <div class="card">
                    <header class="auth-header">
                        <h1 class="auth-title">
                            <div class="logo"> <span class="l l1"></span> <span class="l l2"></span> <span class="l l3"></span> <span class="l l4"></span> <span class="l l5"></span> </div> KOPERASI BAHAGIA JOMBANG </h1>
                    </header>
                    <div class="auth-content">
                        <form id="login-form" action="<?php echo site_url('login/sign'); ?>" method="post" novalidate="">
                            <div class="form-group"> <label for="username">Username</label> <input type="text" class="form-control underlined" name="username" id="username" placeholder="Username" > </div>
                            <div class="form-group"> <label for="password">Password</label> <input type="password" class="form-control underlined" name="password" id="password" placeholder="Password" > </div>
                            <div class="form-group"> <button type="submit" class="btn btn-block btn-primary">Login</button> </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Reference block for JS -->
        <script src="<?php echo base_url('template/js/vendor.js')?>"></script>
        <script src="<?php echo base_url('template/js/app.js')?>"></script>
    </body>
</html>